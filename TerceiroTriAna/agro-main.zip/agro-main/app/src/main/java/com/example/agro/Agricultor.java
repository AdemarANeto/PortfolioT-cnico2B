package com.example.agro;

import com.example.agro.viacep.CEP;

public class Agricultor {
    private Integer caf;
    private String email;
    private String senha;
    private CEP cep;

    public Agricultor(Integer caf, String email, String senha, CEP cep) {
        this.caf = caf;
        this.email = email;
        this.senha = senha;
        this.cep = cep;
    }

    public Agricultor() {
    }

    public Integer getCrmv() {
        return caf;
    }

    public void setCrmv(Integer crmv) {
        this.caf = crmv;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public Integer getCaf() {
        return caf;
    }

    public void setCaf(Integer caf) {
        this.caf = caf;
    }

    public CEP getCep() {
        return cep;
    }

    public void setCep(CEP cep) {
        this.cep = cep;
    }
}
