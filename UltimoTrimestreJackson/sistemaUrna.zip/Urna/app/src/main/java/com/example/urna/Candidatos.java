package com.example.urna;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Candidatos {
    private Integer numero;
    private String Nome;
    private String Cargo;

    public Candidatos() {
    }
    public Candidatos(Integer numero, String nome, String cargo) {
        this.numero = numero;
        Nome = nome;
        Cargo = cargo;
    }
    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getCargo() {
        return Cargo;
    }

    public void setCargo(String cargo) {
        Cargo = cargo;
    }

    public void salvar(){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.child("Candidatos").child(numero.toString()).setValue(this);
    }
}
