package com.example.urna;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class ContarVotos extends AppCompatActivity {

    static int bolsonaro, luladrao, soraya, simone, padre, felipe, ciro, nulo, branco;
    TextView boletim;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contar_votos);
        getSupportActionBar().hide();
        boletim = findViewById(R.id.boletim);


        String boletimUrna = "----- Boletim ----- \n " +
                "Bolsonaro: " + bolsonaro + "\n" +
                "Lula: " + luladrao + "\n" +
                "Ciro: " + ciro + "\n" +
                "Padre: " + padre + "\n" +
                "Felipe: " + felipe + "\n" +
                "Simone: " + simone + "\n" +
                "Soraya: " + soraya + "\n" +
                "Nulo: " + nulo + "\n" +
                "Branco: " + branco;

        boletim.setText(boletimUrna);
    }
}