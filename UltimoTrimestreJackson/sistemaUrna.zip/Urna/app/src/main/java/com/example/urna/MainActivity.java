package com.example.urna;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    static ArrayList<String> cpfEleitor = new ArrayList<>();
    private EditText cpf;
    private Boolean verificaEleitor = false;
    static Eleitor eleitor;
    ArrayList<Boolean> eleitores = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        cpf = findViewById(R.id.cpf);
        eleitor = new Eleitor();

    }

    public void comecar(){

        if(verifica() == true){
            if(cpf.getText().toString().length() == 11){
                eleitor.setCpf(cpf.getText().toString());
                Intent i = new Intent(this, Urna.class);
                startActivity(i);
            }else{
                Toast.makeText(this, "Insira um CPF valido", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this, "Voce ja votou", Toast.LENGTH_SHORT).show();
        }
        eleitores.clear();

    }


    public void verificaCpf(View view) {

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Eleitores");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot d : snapshot.getChildren()){
                    Eleitor e = d.getValue(Eleitor.class);
                    if (e.getCpf().equals(cpf.getText().toString())){
                        eleitores.add(false);
                    }else{
                        eleitores.add(true);
                    }

                }
                comecar();
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public boolean verifica(){
        for(Boolean e : eleitores){
            if(e == false){
                return false;
            }
        }

        return true;

    }

    public void contaVotos(View v){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Eleitores");
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int b = 0, l = 0, si = 0, so = 0,  p = 0, f = 0, c = 0, br = 0, n = 0;
                for(DataSnapshot d : snapshot.getChildren()){
                    Eleitor e = d.getValue(Eleitor.class);
                    if(e.getCanditado() != null){
                        if(e.getCanditado().getNumero() == 22){
                            b++;
                        }else if(e.getCanditado().getNumero() == 13){
                            l++;
                        }else if(e.getCanditado().getNumero() == 15){
                            si++;
                        }else if(e.getCanditado().getNumero() == 44){
                            so++;
                        }else if(e.getCanditado().getNumero() == 14){
                            p++;
                        }else if(e.getCanditado().getNumero() == 30){
                            f++;
                        }else if(e.getCanditado().getNumero() == 12){
                            c++;
                        }else if(e.getCanditado().getNome().equals("Branco")){
                            br++;
                        }
                    }else{
                        n++;
                    }

                }
                ContarVotos.bolsonaro = b;
                ContarVotos.luladrao = l;
                ContarVotos.soraya = so;
                ContarVotos.simone = si;
                ContarVotos.padre = p;
                ContarVotos.felipe = f;
                ContarVotos.ciro = c;
                ContarVotos.nulo = n;
                ContarVotos.branco = br;
                Intent i = new Intent(MainActivity.this, ContarVotos.class);
                startActivity(i);
            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

}