package com.example.urna;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Urna extends AppCompatActivity {

    private TextView number, dataCandidato;
    private ArrayList<Candidatos> candidatos;
    static ArrayList<Integer> votos;
    static int branco = 0;
    Boolean votou = false;
    private Button bt;
    private ImageView foto;

    private Candidatos c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_urna);
        getSupportActionBar().hide();
        number = findViewById(R.id.number);
        dataCandidato = findViewById(R.id.dataCanditado);
        foto = findViewById(R.id.foto);

        if (votos == null) {
            votos = new ArrayList<>();
        }
        if (candidatos == null) {
            candidatos = new ArrayList<>();
            candidatos.add(new Candidatos(22, "Bolsonaro", "presidente"));
            candidatos.add(new Candidatos(13, "Luladrao", "presidente"));
            candidatos.add(new Candidatos(12, "Ciro Gomes", "presidente"));
            candidatos.add(new Candidatos(30, "Felipe D'avila", "presidente"));
            candidatos.add(new Candidatos(14, "Padre Kelmon", "presidente"));
            candidatos.add(new Candidatos(15, "Simone Tebet", "presidente"));
            candidatos.add(new Candidatos(44, "Soraya", "presidente"));
        }

    }


    public void num1(View v) {
        if (number.getText().toString().length() < 2) {
            number.setText(number.getText().toString() + 1);
            alteraTexto();
        }
    }

    public void num2(View v) {
        if (number.getText().toString().length() < 2) {
            number.setText(number.getText().toString() + 2);
            alteraTexto();
        }

    }

    public void num3(View v) {
        if (number.getText().toString().length() < 2) {
            number.setText(number.getText().toString() + 3);
            alteraTexto();
        }

    }

    public void num4(View v) {
        if (number.getText().toString().length() < 2) {
            number.setText(number.getText().toString() + 4);
            alteraTexto();

        }
    }

    public void num5(View v) {
        if (number.getText().toString().length() < 2) {
            number.setText(number.getText().toString() + 5);
            alteraTexto();
        }
    }

    public void num6(View v) {
        if (number.getText().toString().length() < 2) {
            number.setText(number.getText().toString() + 6);
            alteraTexto();
        }
    }

    public void num7(View v) {
        if (number.getText().toString().length() < 2) {
            number.setText(number.getText().toString() + 7);
            alteraTexto();
        }
    }

    public void num8(View v) {
        if (number.getText().toString().length() < 2) {
            number.setText(number.getText().toString() + 8);
            alteraTexto();
        }
    }

    public void num9(View v) {
        if (number.getText().toString().length() < 2) {
            number.setText(number.getText().toString() + 9);
            alteraTexto();
        }
    }

    public void num0(View v) {
        if (number.getText().toString().length() < 2) {
            number.setText(number.getText().toString() + 0);
            alteraTexto();
        }
    }

    public void corrige(View v) {
        if (!number.getText().toString().equals("")) {
            String temp = number.getText().toString();
            int posicaoRemovida = temp.length() - 1;
            temp = temp.substring(0, posicaoRemovida);
            number.setText(temp);
            alteraTexto();
        }

    }

    public void confirma(View v) {
        if (votou == false) {
            String dataCandidatoString = "Nulo";
            if (confereVotos() == true) {
                dataCandidatoString = c.getNome() + "\n" + c.getNumero();
            } else {
                votos.add(Integer.parseInt(number.getText().toString()));
            }

            dataCandidato.setText(dataCandidatoString);
            dataCandidato.setVisibility(View.VISIBLE);
            votou = true;

            MainActivity.eleitor.setCanditado(c);
            System.out.println("CPF: " + MainActivity.eleitor.getCpf());
            MainActivity.eleitor.salvar();

            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
            Toast.makeText(this, "Voce votou", Toast.LENGTH_SHORT).show();
        } else {
            MainActivity.eleitor.setCanditado(new Candidatos(00, "Nulo", "Presidente"));
            MainActivity.eleitor.salvar();
            Toast.makeText(this, "Você ja votou", Toast.LENGTH_SHORT).show();
        }


    }

    public boolean confereVotos() {
        for (Candidatos candidato : candidatos) {
            if (candidato.getNumero() == Integer.parseInt(number.getText().toString())) {
                votos.add(candidato.getNumero());
                c = candidato;

                return true;
            }
        }
        return false;
    }

    public void branco(View v) {
        if (votou == false) {
            String temp = "Branco";
            dataCandidato.setText(temp);
            dataCandidato.setVisibility(View.VISIBLE);
            c = new Candidatos();
            c.setCargo("");
            c.setCargo("");
            c.setNumero(0);
            branco += 1;
            votou = true;
            bt.setVisibility(View.VISIBLE);
            Toast.makeText(this, "Voce votou", Toast.LENGTH_SHORT).show();
            MainActivity.eleitor.setCanditado(new Candidatos(00, "Branco", "Presidente"));
            MainActivity.eleitor.salvar();
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        } else {
            Toast.makeText(this, "Você ja votou", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onBackPressed() {
        // não chame o super desse método
    }


    public void alteraTexto() {
        if (number.getText().toString().length() == 2) {
            if (Integer.parseInt(number.getText().toString()) == 22) {
                dataCandidato.setText("Bolsonaro \n 22");
            } else if (Integer.parseInt(number.getText().toString()) == 13) {
                dataCandidato.setText("Lula \n 13");
            } else if (Integer.parseInt(number.getText().toString()) == 12) {
                dataCandidato.setText("Ciro Gomes \n 12");
            } else if (Integer.parseInt(number.getText().toString()) == 30) {
                dataCandidato.setText("Felipe D'Avilla \n 30");
            } else if (Integer.parseInt(number.getText().toString()) == 14) {
                dataCandidato.setText("Padre Kelmon \n 14");
            } else if (Integer.parseInt(number.getText().toString()) == 15) {
                dataCandidato.setText("Simone \n 15");
            } else if (Integer.parseInt(number.getText().toString()) == 44) {
                dataCandidato.setText("Soraya \n 44");
            } else {
                dataCandidato.setText("Nulo \n " + number.getText());
            }
        } else {
            dataCandidato.setText("");
        }
        dataCandidato.setVisibility(View.VISIBLE);
    }
}




