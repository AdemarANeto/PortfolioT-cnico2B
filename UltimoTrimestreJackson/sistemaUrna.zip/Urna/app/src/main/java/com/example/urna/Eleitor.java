package com.example.urna;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Eleitor {
    private String cpf;
    private Candidatos canditado;
    public Eleitor() {
    }
    public Eleitor(String cpf, Candidatos canditado) {
        this.cpf = cpf;
        this.canditado = canditado;
    }
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Candidatos getCanditado() {
        return canditado;
    }

    public void setCanditado(Candidatos canditado) {
        this.canditado = canditado;
    }

    public void salvar(){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.child("Eleitores").child(cpf).setValue(this);
    }
}
